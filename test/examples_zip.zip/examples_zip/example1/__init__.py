"""Simplest test - importing modules"""

from initdotpy import auto_import
auto_import(__name__, __file__)
