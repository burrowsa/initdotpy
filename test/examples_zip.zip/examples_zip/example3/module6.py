from mock import sentinel


__all__ = ['A', 'B', 'C']


A = sentinel.A
B = sentinel.B
C = sentinel.C
