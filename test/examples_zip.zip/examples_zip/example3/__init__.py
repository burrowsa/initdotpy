"""Tests importing module contents"""
from initdotpy import auto_import_contents
auto_import_contents(__name__, __file__)
