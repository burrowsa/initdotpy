from mock import sentinel


__all__ = ['X', 'Y', 'Z']


X = sentinel.X
Y = sentinel.Y
Z = sentinel.Z
